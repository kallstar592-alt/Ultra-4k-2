# Ultra Upscaler for Android

Android port of the Ultra Upscaler desktop app: a streaming browser whose pages get a WebGL
video upscaler (Catmull-Rom bicubic + adaptive sharpen + brightness/contrast/saturation)
and, on YouTube, automatic highest-quality selection.

## Get the APK (no Android Studio needed)
1. Create a new **private** GitHub repo and upload everything in this folder
   (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs automatically
   (or click "Run workflow").
3. When it finishes (about 3-5 min), open the run and download the **UltraUpscaler-apk**
   artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, open it, and allow "Install unknown apps" when asked.

## Or build with Android Studio
Open this folder in Android Studio, let Gradle sync, then
Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Differences from the desktop version
- Native WebView instead of Electron; the shader/logic script is `app/src/main/assets/inject.js`,
  generated from the original `preload.js`.
- Default render target is **4K** (8K/10K are still selectable, but heavy on phone GPUs;
  the app steps down automatically if the GPU can't allocate or keep up).
- Added a "Desktop site" toggle (Tune panel); the YouTube max-quality logic works best there.
- Ctrl+Shift+U shortcut replaced by the Enhance switch.
- Same limits as desktop: DRM sites (Netflix, Disney+, Prime Video) won't play, and some
  sites serve video that the browser blocks from GPU processing (status bar will say so).

## New in this version
- **Smart** switch: edge-aware enhancement (Anime4K-style shock filter) that runs on the GPU
  before the upscale. Cleans up soft edges and line art. It is NOT a trained neural network.
  Adjust with "Smart strength" in the gear panel. Costs extra battery/heat.
- **Incognito** (sunglasses button): opens a private window running in its own Android process
  with separate cookies/cache/storage (needs Android 9+). Nothing is saved, the window is
  hidden from screenshots/recents, search uses DuckDuckGo, and everything is erased when you
  close it (X button or Back). Your normal logins are never touched.

## Note
This project was written without being able to compile it in the authoring environment.
If the build reports an error, send me the log and I'll fix it.
