package com.ultraupscaler.app;

/**
 * Incognito window. Declared in the manifest with android:process=":private", so it gets its own
 * WebView cookie jar, cache and storage (separate from the normal browser). Everything is erased
 * when the window is closed, and nothing is saved to disk.
 */
public class PrivateActivity extends MainActivity {
    @Override
    protected boolean isPrivate() {
        return true;
    }
}
