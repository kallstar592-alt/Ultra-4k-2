package com.ultraupscaler.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ultra Upscaler for Android: a streaming browser whose pages get a WebGL video upscaler
 * (assets/inject.js) injected after load. Native port of the Electron desktop app.
 *
 * PrivateActivity (a subclass running in its own Android process with its own WebView data
 * directory) provides the Incognito window.
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://www.youtube.com";
    private static final String HOME_PRIVATE = "https://duckduckgo.com";
    private static final String[] TARGET_LABELS = {"4K", "8K UHD", "10K"};
    private static final String[] TARGET_VALUES = {"4k", "8k", "10k"};

    private static boolean privatePrepared = false;

    // settings
    private boolean enabled = true, autoQuality = true, adaptive = true, desktop = false, smart = false;
    private String target = "4k";
    private int sharp = 35, bright = 100, contrast = 100, sat = 100, smartStrength = 60;

    private SharedPreferences prefs;
    private FrameLayout root;
    private LinearLayout main;
    private WebView web;
    private EditText urlBox;
    private TextView statusView;
    private ScrollView panelScroll;
    private LinearLayout panel;
    private String injectJs = "";
    private String mobileUA, desktopUA;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    /** Overridden by PrivateActivity. */
    protected boolean isPrivate() {
        return false;
    }

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // The private window runs in its own process: give it its own WebView data directory
        // BEFORE any WebView is created, and start it from a clean slate.
        if (isPrivate()) preparePrivateProcess();

        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vq", Context.MODE_PRIVATE);
        loadSettings();
        injectJs = readAsset("inject.js");

        if (isPrivate()) {
            // Blank in screenshots and the recent-apps screen.
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE);
        }

        buildUi();
        setupWebView();
        buildPanel();

        web.loadUrl(isPrivate() ? HOME_PRIVATE : HOME);
    }

    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    @Override
    protected void onDestroy() {
        if (web != null) {
            if (isPrivate()) wipePrivateData();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ incognito

    private void preparePrivateProcess() {
        if (privatePrepared) return;
        privatePrepared = true;
        try {
            File data = new File(getApplicationInfo().dataDir);
            deleteRecursive(new File(data, "app_webview_incognito"));
            deleteRecursive(new File(getCacheDir(), "WebView_incognito"));
        } catch (Throwable ignored) { }
        if (Build.VERSION.SDK_INT >= 28) {
            try { WebView.setDataDirectorySuffix("incognito"); } catch (Throwable ignored) { }
        }
    }

    @SuppressWarnings("deprecation")
    private void wipePrivateData() {
        try { web.clearHistory(); } catch (Throwable ignored) { }
        try { web.clearCache(true); } catch (Throwable ignored) { }
        try { web.clearFormData(); } catch (Throwable ignored) { }
        try { WebStorage.getInstance().deleteAllData(); } catch (Throwable ignored) { }
        try {
            final CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(ok -> cm.flush());
            cm.flush();
        } catch (Throwable ignored) { }
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    private void openPrivateWindow() {
        if (Build.VERSION.SDK_INT < 28) {
            Toast.makeText(this, "Incognito needs Android 9 or newer", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(new Intent(this, PrivateActivity.class));
    }

    // ------------------------------------------------------------------ settings

    private void loadSettings() {
        enabled = prefs.getBoolean("enabled", true);
        autoQuality = prefs.getBoolean("autoQuality", true);
        adaptive = prefs.getBoolean("adaptive", true);
        desktop = prefs.getBoolean("desktop", false);
        smart = prefs.getBoolean("smart", false);
        target = prefs.getString("target", "4k");
        sharp = prefs.getInt("sharp", 35);
        bright = prefs.getInt("bright", 100);
        contrast = prefs.getInt("contrast", 100);
        sat = prefs.getInt("sat", 100);
        smartStrength = prefs.getInt("smartStrength", 60);
    }

    private void saveAndPush() {
        // The private window never writes anything to disk.
        if (!isPrivate()) {
            prefs.edit()
                    .putBoolean("enabled", enabled).putBoolean("autoQuality", autoQuality)
                    .putBoolean("adaptive", adaptive).putBoolean("desktop", desktop)
                    .putBoolean("smart", smart)
                    .putString("target", target)
                    .putInt("sharp", sharp).putInt("bright", bright)
                    .putInt("contrast", contrast).putInt("sat", sat)
                    .putInt("smartStrength", smartStrength)
                    .apply();
        }
        push();
    }

    private String settingsJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("enabled", enabled);
            o.put("target", target);
            o.put("sharpness", sharp);
            o.put("brightness", bright);
            o.put("contrast", contrast);
            o.put("saturation", sat);
            o.put("autoQuality", autoQuality);
            o.put("adaptive", adaptive);
            o.put("smart", smart);
            o.put("smartStrength", smartStrength);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    private void push() {
        if (web != null) web.evaluateJavascript("window.__vqSet&&window.__vqSet(" + settingsJson() + ");", null);
    }

    private void inject() {
        if (web == null || injectJs.isEmpty()) return;
        web.evaluateJavascript(injectJs + "\n;window.__vqSet&&window.__vqSet(" + settingsJson() + ");", null);
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Button btn(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        final boolean pv = isPrivate();
        int cRoot = pv ? 0xFF140B1F : 0xFF0E0F12;
        int cBar1 = pv ? 0xFF2B1A44 : 0xFF16181D;
        int cBar2 = pv ? 0xFF22143A : 0xFF12141A;

        root = new FrameLayout(this);
        root.setBackgroundColor(cRoot);

        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // row 1: navigation + address bar + incognito + tune
        LinearLayout bar1 = new LinearLayout(this);
        bar1.setOrientation(LinearLayout.HORIZONTAL);
        bar1.setGravity(Gravity.CENTER_VERTICAL);
        bar1.setBackgroundColor(cBar1);
        bar1.setPadding(dp(4), dp(2), dp(4), dp(2));

        bar1.addView(btn("\u25c0", v -> { if (web.canGoBack()) web.goBack(); }));
        bar1.addView(btn("\u25b6", v -> { if (web.canGoForward()) web.goForward(); }));
        bar1.addView(btn("\u27f3", v -> web.reload()));

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setHint(pv ? "Private search or address" : "Web address or search");
        urlBox.setTextSize(14);
        urlBox.setSelectAllOnFocus(true);
        urlBox.setImeOptions(pv
                ? (EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING)
                : EditorInfo.IME_ACTION_GO);
        urlBox.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI
                | (pv ? android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS : 0));
        urlBox.setOnEditorActionListener((v, actionId, event) -> {
            go(urlBox.getText().toString());
            return true;
        });
        bar1.addView(urlBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // Incognito: opens the private window; inside the private window it closes it.
        bar1.addView(btn(pv ? "\u2715" : "\ud83d\udd76", v -> {
            if (pv) finish(); else openPrivateWindow();
        }));

        bar1.addView(btn("\u2699", v -> {
            if (panelScroll.getVisibility() == View.VISIBLE) {
                panelScroll.setVisibility(View.GONE);
            } else {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                panelScroll.getLayoutParams().height = (int) (dm.heightPixels * 0.45f);
                panelScroll.setVisibility(View.VISIBLE);
                panelScroll.requestLayout();
            }
        }));
        main.addView(bar1);

        // row 2: Enhance switch + Smart switch + render target
        LinearLayout bar2 = new LinearLayout(this);
        bar2.setOrientation(LinearLayout.HORIZONTAL);
        bar2.setGravity(Gravity.CENTER_VERTICAL);
        bar2.setBackgroundColor(cBar2);
        bar2.setPadding(dp(10), dp(2), dp(10), dp(2));

        Switch sw = new Switch(this);
        sw.setText("Enhance  ");
        sw.setTextColor(0xFFE8EAED);
        sw.setChecked(enabled);
        sw.setOnCheckedChangeListener((b, on) -> { enabled = on; saveAndPush(); });
        bar2.addView(sw);

        Switch swSmart = new Switch(this);
        swSmart.setText("Smart  ");
        swSmart.setTextColor(0xFFE8EAED);
        swSmart.setChecked(smart);
        swSmart.setOnCheckedChangeListener((b, on) -> { smart = on; saveAndPush(); });
        bar2.addView(swSmart);

        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, TARGET_LABELS));
        for (int i = 0; i < TARGET_VALUES.length; i++) if (TARGET_VALUES[i].equals(target)) sp.setSelection(i);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (!TARGET_VALUES[pos].equals(target)) { target = TARGET_VALUES[pos]; saveAndPush(); }
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        bar2.addView(sp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        main.addView(bar2);

        // tune panel (hidden until the gear is tapped)
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(8));
        panelScroll = new ScrollView(this);
        panelScroll.setBackgroundColor(cBar2);
        panelScroll.addView(panel);
        panelScroll.setVisibility(View.GONE);
        main.addView(panelScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(200)));

        // web view
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        main.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // status bar
        statusView = new TextView(this);
        statusView.setTextColor(pv ? 0xFFC9A7FF : 0xFF9AA3B2);
        statusView.setTextSize(11);
        statusView.setSingleLine(true);
        statusView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        statusView.setBackgroundColor(cBar2);
        statusView.setPadding(dp(10), dp(3), dp(10), dp(3));
        statusView.setText(pv
                ? "Private window \u2013 history, cookies and cache are erased when you close it"
                : "Starting\u2026");
        main.addView(statusView);

        setContentView(root);
    }

    private interface IntCb { void on(int v); }
    private interface CheckBoxCb { void on(boolean v); }

    private View slider(String label, final int min, int max, int init, final String suffix, final IntCb cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(4), 0, dp(4));
        final TextView t = new TextView(this);
        t.setTextColor(0xFFE8EAED);
        t.setText(label + ": " + init + suffix);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(init - min);
        final String lbl = label;
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                t.setText(lbl + ": " + v + suffix);
                if (fromUser) cb.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(t);
        box.addView(sb);
        return box;
    }

    private CheckBox check(String label, boolean value, CheckBoxCb cb) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(0xFFE8EAED);
        c.setChecked(value);
        c.setOnCheckedChangeListener((b, on) -> cb.on(on));
        return c;
    }

    private void buildPanel() {
        panel.removeAllViews();
        panel.addView(slider("Smart strength", 0, 100, smartStrength, "", v -> { smartStrength = v; saveAndPush(); }));
        panel.addView(slider("Sharpness", 0, 100, sharp, "", v -> { sharp = v; saveAndPush(); }));
        panel.addView(slider("Brightness", 50, 150, bright, "%", v -> { bright = v; saveAndPush(); }));
        panel.addView(slider("Contrast", 50, 150, contrast, "%", v -> { contrast = v; saveAndPush(); }));
        panel.addView(slider("Saturation", 0, 200, sat, "%", v -> { sat = v; saveAndPush(); }));
        panel.addView(check("Auto max quality (YouTube)", autoQuality, v -> { autoQuality = v; saveAndPush(); }));
        panel.addView(check("Auto-lower render size if GPU struggles", adaptive, v -> { adaptive = v; saveAndPush(); }));
        panel.addView(check("Desktop site (better quality options)", desktop, v -> {
            desktop = v; saveAndPush(); applyUserAgent(); web.reload();
        }));
        panel.addView(btn("Reset", v -> {
            sharp = 35; bright = 100; contrast = 100; sat = 100; smartStrength = 60;
            saveAndPush();
            buildPanel();
        }));
    }

    // ------------------------------------------------------------------ web view

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @SuppressWarnings("deprecation")
    private void setupWebView() {
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        if (isPrivate()) {
            ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
            ws.setSaveFormData(false);
            ws.setGeolocationEnabled(false);
        }

        // Look like a normal Chrome (not an embedded WebView) so streaming sites don't reject us.
        String def = ws.getUserAgentString();
        mobileUA = def.replace("; wv", "").replaceFirst("Version/\\S+\\s", "");
        Matcher m = Pattern.compile("Chrome/(\\S+)").matcher(def);
        String chromeVer = m.find() ? m.group(1) : "124.0.0.0";
        desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + chromeVer + " Safari/537.36";
        applyUserAgent();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        // Only exposes a status-text setter to pages.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void status(final String text) {
                runOnUiThread(() -> { if (statusView != null) statusView.setText(text); });
            }
        }, "AndroidVQ");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String scheme = req.getUrl().getScheme();
                // Stay in the app for web links; ignore intent:/market: and similar.
                return !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap icon) { showUrl(url); }
            @Override public void onPageFinished(WebView v, String url) { showUrl(url); inject(); }
            @Override public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) { showUrl(url); }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCb = callback;
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                main.setVisibility(View.GONE);
                setFullscreenMode(true);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }
            @Override public void onHideCustomView() { hideCustom(); }
            @Override public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
    }

    private void applyUserAgent() {
        WebSettings ws = web.getSettings();
        ws.setUserAgentString(desktop ? desktopUA : mobileUA);
        ws.setUseWideViewPort(desktop);
        ws.setLoadWithOverviewMode(desktop);
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        main.setVisibility(View.VISIBLE);
        setFullscreenMode(false);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (customCb != null) { customCb.onCustomViewHidden(); customCb = null; }
    }

    @SuppressWarnings("deprecation")
    private void setFullscreenMode(boolean on) {
        getWindow().getDecorView().setSystemUiVisibility(on
                ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showUrl(String url) {
        if (url != null && urlBox != null && !urlBox.hasFocus()) urlBox.setText(url);
    }

    private void go(String text) {
        text = text.trim();
        if (text.isEmpty()) return;
        String u;
        if (text.matches("(?i)^https?://.*")) u = text;
        else if (text.matches("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$")) u = "https://" + text;
        else {
            try {
                String q = URLEncoder.encode(text, "UTF-8");
                u = (isPrivate() ? "https://duckduckgo.com/?q=" : "https://www.google.com/search?q=") + q;
            } catch (Exception e) { return; }
        }
        web.loadUrl(u);
        urlBox.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
